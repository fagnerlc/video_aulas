import 'package:cadevo/controllers/appController.dart';
import 'package:cadevo/controllers/authController.dart';

 AppController appController = AppController.instance;
 AuthController authController = AuthController.instance;