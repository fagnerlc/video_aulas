package com.santosenoque.cadevo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
