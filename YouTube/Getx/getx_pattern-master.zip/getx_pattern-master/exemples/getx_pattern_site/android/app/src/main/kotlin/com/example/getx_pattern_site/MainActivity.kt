package com.example.getx_pattern_site

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
