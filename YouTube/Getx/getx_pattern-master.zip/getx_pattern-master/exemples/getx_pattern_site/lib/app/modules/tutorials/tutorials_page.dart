import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TutorialsPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Scaffold(
    appBar: AppBar(title: Text('TutorialsPage')),

    body: Container(
      child: Text('Tutorials')
      ),
    );
  }
}