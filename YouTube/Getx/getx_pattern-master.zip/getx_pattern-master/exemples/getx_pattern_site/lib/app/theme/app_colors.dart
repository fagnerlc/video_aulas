import 'package:flutter/material.dart';

final Color spotlightColor = Color(0xffea5a47);
final Color softBlue = Color(0xff61b2e4);