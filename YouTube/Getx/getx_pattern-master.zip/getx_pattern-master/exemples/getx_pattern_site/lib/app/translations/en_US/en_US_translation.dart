part './strings_en_us.dart';

final Map<String, String> enUs = {
  'Inicio' : INICIO,
  'Estrutura' : STRUCT,
  'GetX' : GETX,
  'Data' : DATA,
  'Provider' : PROVEDOR,
  'Model' : MODEL,
  'Repository' : REPOSITORIO,
  'Controllador' : CONTROLLADOR,
  'UI' : UI,
  'Routes' : ROTAS,
  'Translations' : TRANSLATIONS,
  'Tutorials' : TUTORIAIS,
  'oi' : 'hello'
};
