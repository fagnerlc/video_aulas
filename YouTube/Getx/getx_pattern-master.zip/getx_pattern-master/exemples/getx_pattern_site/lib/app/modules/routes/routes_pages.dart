import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RoutesPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Scaffold(
    appBar: AppBar(title: Text('RoutesPage')),

    body: Container(
      child: Text('Routes')
      ),
    );
  }
}