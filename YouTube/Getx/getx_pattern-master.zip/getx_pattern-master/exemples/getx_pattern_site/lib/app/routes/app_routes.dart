part of './app_pages.dart';
abstract class Routes{

  static const INITIAL = '/';
  static const HOME = '/home';
  static const APRESENTACAO = '/apresentacao';
  static const CADASTRO = '/cadastro';

}