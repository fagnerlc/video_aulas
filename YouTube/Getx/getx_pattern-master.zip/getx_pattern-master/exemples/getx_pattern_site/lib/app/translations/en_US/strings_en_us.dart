part of './en_US_translation.dart';

const INICIO = "Home";
const STRUCT = "Struct";
const GETX = 'GetX';
const DATA = 'Data';
const PROVEDOR = 'Provider';
const REPOSITORIO = 'Repository';
const CONTROLLADOR = 'Controller';
const ROTAS = 'Routes';
const TRANSLATIONS = 'Translations';
const TUTORIAIS = 'Tutorials';
const MODEL = 'Model';
const UI = 'UI';
const OI = 'Hello';
