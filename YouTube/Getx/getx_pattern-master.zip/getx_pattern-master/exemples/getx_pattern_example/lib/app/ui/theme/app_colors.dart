import 'package:flutter/material.dart';

final Color exampleColor = Colors.white;