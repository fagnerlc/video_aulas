part of './app_pages.dart';

abstract class Routes{

  static const INITIAL = '/';
  static const DETAILS = '/details';
}