final Map<String, String> ptBR = {
  'oi' : 'oi'
};