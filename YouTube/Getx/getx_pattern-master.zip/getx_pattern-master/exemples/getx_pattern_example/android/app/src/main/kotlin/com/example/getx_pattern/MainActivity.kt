package com.example.getx_pattern

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
