import 'package:get/get.dart';

class LoginformController extends GetxController {
  //TODO: Implement LoginformController
  
  final count = 0.obs;

  @override
  void onInit() {}

  @override
  void onReady() {}

  @override
  void onClose() {}

  increment() => count.value++;
}
