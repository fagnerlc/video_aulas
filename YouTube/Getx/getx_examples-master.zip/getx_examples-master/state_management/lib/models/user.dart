class User {
  User({this.name = '', this.count = 0});
  String name;
  int count;
}
