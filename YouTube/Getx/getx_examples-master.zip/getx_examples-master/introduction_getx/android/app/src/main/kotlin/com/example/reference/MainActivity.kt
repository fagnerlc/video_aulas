package com.example.reference

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
