class Routes {
  static Future<String> get initialRoute async {
    // TODO: implement method
    return HOME;
  }
  static const HOME = '/home';
}