package com.tadaspetra.clean_cli

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
